#include<cstdio>
#include<cstring>
char a[30],b[30],c[30];



 int num_now;


void solve(char *a,char *b){
char *p=b;
while(*p!=*a) p++;
p++;
solve(,p)
}

int main(){
int length;
        while(scanf("%s",a)!=EOF){
                scanf("%s",b);
                num_now=0;
                length=strlen(a);
                solve(a,b);

        }
    return 0;
}
