/*************************************************************************
	> File Name: UVA_11212.cpp
	> Author: fuyu0425/a0919610611
	> School: National Chiao Tung University
	> Team: NCTU_Ragnorok
	> Mail: a0919610611@gmail.com
	> Created Time: 西元2016年04月06日 (週三) 00時43分26秒
 ************************************************************************/
#include <bits/stdc++.h>
using namespace std;

int main()
{

    int T;
    while(scanf("%d",&T) &&　Ｔ)
    ｛
            int a[11]={};
            int i,j;
            for(i=1;i<=T;i++)
            {
                scanf("%d",a+i);

            }
     ｝
     return 0;
}
